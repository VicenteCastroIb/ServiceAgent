# Handoff: Panel Redesign (Cream/Gold/Rose)

## Overview
Redesign of the business-owner admin panel (`frontend/panel`) — currently a bare Tailwind default (white bg, gray borders, blue-600 buttons) — into a warm cream/pastel visual system matching the ServiceAgent brand direction: gold (WhatsApp-side) + dusty rose (Instagram-side) accents on a cream background.

## About the Design File
`panel.html` is a **design reference built in plain HTML/inline-CSS** with mock data — it shows layout, tokens, copy, and interaction intent (tab switching, conversation selection, handoff resume). It is NOT production code to copy in. Recreate it inside the existing Next.js + Tailwind codebase (`frontend/panel`), keeping the app's real data flow (`src/lib/api.ts`, `useRequireAuth`, `CuentaGate`) — only the visual layer changes.

## Fidelity
High-fidelity for color, type, spacing, and card/layout structure. The mock data (3 tenants, 3 conversations, 2 handoffs) is illustrative — wire real data from the existing `listarTenants` / `listarConversaciones` / `listarHandoffs` calls.

## Design Tokens
- Background: `#faf7f1` (page) · alternating panel fill `#fffdf9` (cards) · row header `#f2ede1`
- Text: `#2b2620` (primary) · `rgba(43,38,32,0.4–0.65)` (secondary/tertiary/muted)
- Borders: `rgba(43,38,32,0.07–0.12)`
- Gold accent (WhatsApp / primary actions): solid `#b9862f`, dark text `#8a5f22`, tints `rgba(185,134,47,0.08–0.28)`
- Rose accent (Instagram / secondary chips): solid `#c9788f`, dark text `#8a4a5a`, tints `rgba(201,120,143,0.1–0.3)`
- Warning (moroso/handoff badge): amber `#f59e0b` bg / `#b45309` text — kept as a distinct semantic color, not part of the brand duo
- Error (delete/moroso label): `#f87171` — kept distinct
- Type: Inter, 400–800. Page titles 24px/800, card titles 16px/700, body 12.5–14px.
- Radius: 16px cards, 8–10px buttons/badges, 999px pills.

## Screens
Single shell with a top nav (logo + 3 tabs) and three tab bodies — recreate as the existing `Nav.tsx` + per-route pages, not as client-side tabs, since the real app already routes `/tenants`, `/conversaciones`, `/handoffs`.

### 1. Nav shell (→ `src/components/Nav.tsx`, `src/app/layout.tsx`)
Sticky header, cream/blur background, logo mark (gold→rose gradient square with "S"), "Panel" label, 3 tab links (active tab gets a gold pill background `rgba(185,134,47,0.14)` + `#8a5f22` text; inactive tabs `rgba(43,38,32,0.6)`), a small unread-count badge (amber) on "Pausadas" when `handoffs.length > 0`, "Admin" status dot, "Cerrar sesión" link.

### 2. Negocios (→ `src/app/tenants/page.tsx`, `src/components/TenantCard.tsx`)
Header row: "Negocios" title + subtitle, "+ Nuevo negocio" gold button (admin only, existing `esAdmin` check).
Card grid (`auto-fit, minmax(300px,1fr)`), each card (`#fffdf9` bg, 16px radius):
- Business name + plan pill (Pro = gold tint, Catálogo = rose tint, Básico = neutral gray tint)
- WhatsApp number (monospace, muted)
- 2-line clamped context blurb
- Subscription info box (muted panel): payment method · vigente hasta DATE, with a red " · morosa"/" · cancelada" suffix when not ACTIVA
- "Registrar pago manual" link (gold)
- Footer row: Contexto / Agendamiento / Catálogo / Pagos links + admin-only red "Eliminar"

### 3. Conversaciones (→ `src/app/conversaciones/page.tsx` + `[id]/page.tsx`)
Redesigned as a two-pane inbox (was a plain table): left pane is a scrollable conversation list (channel-colored dot: gold=WhatsApp, rose=Instagram; client contact, tenant + last message preview, timestamp; selected row gets a gold tint background). Right pane is the open thread: header with client/tenant/channel + a status chip ("IA respondiendo" gold, or "Derivado a humano" amber), the message thread (customer bubbles gold-tinted right-aligned, bot/neutral bubbles cream-gray left-aligned), and a bottom bar with a disabled-look "Escribí para tomar el control…" placeholder + an "IA activa"/"Pausado" chip. This two-pane layout is new relative to the current plain table + separate detail page — worth confirming with the team before building, or keep the existing list+detail-page split and just apply the token/card styling.

### 4. Pausadas (→ `src/app/handoffs/page.tsx`)
Table restyled: cream header row (`#f2ede1`), rows with client (monospace) + reason + a gold "Reanudar bot" button (was blue-600/green-600). Empty state copy unchanged.

## Interactions
- Tab switching (if kept as client tabs) or route navigation (if split back into pages) — either way, active-state styling per the tokens above.
- Conversation row click → loads that thread on the right (or navigates to `/conversaciones/{id}` in the real app).
- "Reanudar bot" removes the row from the pausadas list (calls the existing `reanudarHandoff` API, then re-fetches).

## Not Included
Login page, tenant sub-pages (`/tenants/{id}/edit`, `/agendamiento`, `/catalogo`, `/pagos`), `CuentaGate` paywall screens, `AppointmentsCalendar`, `ProfessionalAvailability`, `ReportesAgendamiento`, `CitaDetailPanel` were not redesigned — apply the same token set (cream bg, gold/rose accents, card radii) to keep them consistent when touched.

## Files
- `panel.html` — design reference (was `ServiceAgent Panel.dc.html`)
- `screenshots/panel.png` — capture of the Negocios tab
