# Handoff: ServiceAgent Dark Rebrand

## Overview
Redesign of the ServiceAgent marketing site (Home, Agendamiento, Ecommerce) from the current light/lime theme into a dark, "Vercel/Linear"-style aesthetic with a green (WhatsApp) + violet (Instagram) accent duo. Copy rewritten to neutral Spanish (no voseo/Chilenismos). Adds photo slots to feature and "how it works" sections, an always-full nav across all three pages, and flexbox-based responsive layout (no fixed-ratio grids, so it collapses cleanly on mobile).

## About the Design Files
The files in this bundle (`landing.html`, `agendamiento.html`, `ecommerce.html`) are **design references built in plain HTML/inline-CSS** — they show the intended look, copy, and behavior. They are NOT production code to copy/paste. The task is to **recreate this design inside the existing Next.js + Tailwind codebase** (`frontend/landing`), reusing its existing component structure (`Header`, `Footer`, `WhatsAppMockup`, `FeatureGrid`, `PricingCards`, `FAQAccordion`, `CTABanner`, `ComparisonSection`, `StepsSection`, `RubrosStrip`) rather than introducing new markup patterns. Only `agendamiento` and `ecommerce` pages exist as routes today — the third page here maps to the existing `/` (home) route.

## Fidelity
**High-fidelity.** Colors, typography, spacing, copy, and card layouts are final. Recreate pixel-close using Tailwind utility classes / the existing `@theme` tokens in `globals.css`, swapping the current light/lime tokens for the dark/green/violet ones listed below.

## Design Tokens

**Colors** (replace the current `--color-ink`/`--color-lime` set in `globals.css`):
- Background: `#0a0a0a` (page), `rgba(255,255,255,0.015–0.02)` for alternating section tint, `rgba(255,255,255,0.02)` card fill
- Borders: `rgba(255,255,255,0.08–0.12)`
- Text: white `#ffffff`, secondary `rgba(255,255,255,0.55–0.65)`, tertiary `rgba(255,255,255,0.4–0.45)`
- Green (WhatsApp) accent: `#22c55e` solid / `#4ade80` light text / tints `rgba(34,197,94,0.06–0.25)`
- Violet (Instagram) accent: `#8b5cf6` solid / `#c4b5fd` light text / `#a78bfa` / tints `rgba(139,92,246,0.06–0.35)`
- Gradients: hero headline gradient `linear-gradient(90deg,#4ade80,#a78bfa)`; CTA/comparison banner `linear-gradient(120deg,#16a34a,#7c3aed)` (green start) or `linear-gradient(120deg,#7c3aed,#16a34a)` (violet start, used on Ecommerce)

**Typography:** Inter (400/500/600/700/800), same as before but swap `Bricolage`/`Hanken` for Inter throughout. Headline sizes use `clamp()`: hero `clamp(34px,4.6vw,56px)`, section h2 `clamp(28px,3.6vw,42px)`. Letter-spacing `-0.02em` to `-0.035em` on headings.

**Radii:** cards `20px`, small tiles `12–14px`, pills `999px`.

**Spacing:** section vertical padding `clamp(72px,9vw,110px)`; card gaps `18–28px`.

## Screens / Views

### 1. Home (maps to `/`, file `landing.html`)
- **Nav**: logo + Inicio / Agendamiento / Ecommerce / Precios, all real links (no disabled/`#` current-page links — active page shown in accent color but still clickable), "Entrar" + "Empieza gratis" pill CTA.
- **Hero**: two-column (flex-wrap, not CSS grid, so it stacks on mobile — see Responsive below). Left: eyebrow pill, H1 with gradient second line, subhead, two CTAs, avatar stack + "+30 locales" social proof, trust microcopy. Right: two overlapping WhatsApp/Instagram chat mockup cards ("Estética Ópalo" green, "Automotriz" violet with a text-only product card — no image — for a radiator quote), diagonally offset, floating animation, radial glow blobs behind.
- **Trust strip**: centered row of category wordmarks (Clínicas, Tiendas online, Peluquerías, Talleres, Dentistas).
- **Bento features** (`#features`): flex-wrap layout, one large 2-unit card ("Omnicanal real") + 4 standard cards, each with a `160px`/`130px` tall photo placeholder on top, no icons (icons were explicitly removed per user request — text-only cards).
- **How it works** (`#como-funciona`): 3 step cards, each with a `150px` photo placeholder above a numbered badge, title, description.
- **Comparison**: 2-column "Sin ServiceAgent" vs "Con ServiceAgent" (gradient-filled) card pair.
- **Pricing** (`#precios`): monthly/annual toggle (interactive, in-component state), Básico/Pro cards, CLP pricing with `es-CL` `toLocaleString` formatting (periods as thousands separators — do not use `es-419`, it renders commas).
- **FAQ** (`#faq`): 5-item accordion, single-open-at-a-time.
- **CTA banner**: gradient block, white button.
- **Footer**: logo blurb, PRODUCTO / RECURSOS / LEGAL columns (no Blog link — removed), social monogram badges (IG/X/in).

### 2. Agendamiento (`agendamiento.html`)
Same nav/footer shell. Hero: teal→green accent variant, "Barbería Norte" mockup. Sections: Rubros strip, Comparison, 3-step "how it works", bento features (Agenda 24/7 large + 4 small, each with photo placeholder), a conversation showcase ("Estética Ópalo"), FAQ (4 items, own accordion state), CTA.

### 3. Ecommerce (`ecommerce.html`)
Violet-led hero ("Tienda Roman" example: customer asks for 2 poleras + 1 buzo, bot replies with an ordered text list of items/sizes/prices and offers to schedule delivery — no product photos, text only). Sections: Rubros strip, Comparison, 3-step "how it works" (each step with photo placeholder), bento features (Vende 24/7 large + 4 small), a custom "A tu medida" pricing card (no toggle — quote-based), a second conversation showcase, FAQ (4 items), CTA.

## Interactions & Behavior
- **Pricing toggle** (Home only): local component state, two buttons, active button gets the green gradient fill; price labels and "Ahorras $X al año" savings line recompute on toggle. Use `(value).toLocaleString("es-CL")` — confirmed correct peso formatting (periods, not commas).
- **FAQ accordion**: click question toggles `open` on that item only (single-open), chevron/plus rotates 45° when open.
- **All nav links are always live** — no disabled or dead "current page" link; the active page is simply colored green/violet.
- **Hover**: standard color/background transitions on links and buttons (see existing Tailwind hover patterns in `Button.tsx`).

## Responsive Behavior
No CSS media queries were used in the prototypes (single inline-style file constraint) — instead:
- Hero two-column sections use `display:flex; flex-wrap:wrap` with each column given `flex-basis` + `min-width` (e.g. `flex:1 1 400px; min-width:300px`) so they stack under ~700–800px viewport width.
- Bento feature grids use `display:flex; flex-wrap:wrap` (NOT CSS Grid `auto-fit` + `grid-column:span`, which breaks at intermediate widths) — the large card is `flex:2 1 480px`, small cards `flex:1 1 260px`.
- Footer and comparison/pricing/step grids use `grid-template-columns:repeat(auto-fit,minmax(Npx,1fr))`.
In the real codebase, translate this intent into standard Tailwind responsive classes (`grid-cols-1 md:grid-cols-3`, etc.) rather than replicating the flex-basis trick — Tailwind's breakpoint system is the better tool there.

## Assets — Photo Placeholders Needed
Each `<image-slot>` in the prototypes marks a spot that needs a real photo. Suggested photo briefs (id → subject):
- `feat-omnicanal` — business owner replying to WhatsApp and Instagram from their phone
- `feat-24-7` — phone notification at night, answered instantly
- `feat-handoff` — team member taking a call / reviewing the panel
- `feat-crm` — screen showing panel-to-CRM/spreadsheet integration
- `feat-precio` — product catalog with real prices on a counter
- `step-1-conectar` / `agenda-step-1` / `ecom-step-1` — phone linking WhatsApp Business + Instagram
- `step-2-entrenar` / `agenda-step-2` / `ecom-step-2` — owner loading catalog/prices into the panel
- `step-3-vender` / `agenda-step-3` / `ecom-step-3` — business running at night / confirmed delivery link
- (Agendamiento) `agenda-feat-noshow`, `agenda-feat-confirma`, `agenda-feat-handoff`, `agenda-feat-natural`
- (Ecommerce) `ecom-feat-busca`, `ecom-feat-stock`, `ecom-feat-recomienda`, `ecom-feat-chat`

## Files
- `landing.html` — Home page design reference (was `ServiceAgent Landing.dc.html`)
- `agendamiento.html` — Agendamiento page design reference
- `ecommerce.html` — Ecommerce page design reference
- `screenshots/landing.png`, `screenshots/agendamiento.png`, `screenshots/ecommerce.png` — top-of-page captures of each design

Existing repo files these map to (`frontend/landing/src/...`):
- `app/page.tsx`, `app/agendamiento/page.tsx`, `app/ecommerce/page.tsx`
- `app/globals.css` (color tokens)
- `components/Header.tsx`, `components/Footer.tsx`
- `components/WhatsAppMockup.tsx` (chat bubble colors need a dark-mode variant)
- `components/FeatureGrid.tsx`, `components/ComparisonSection.tsx`, `components/StepsSection.tsx`, `components/PricingCards.tsx`, `components/FAQAccordion.tsx`, `components/CTABanner.tsx`, `components/RubrosStrip.tsx`
- `lib/accents.ts` (accent gradient definitions — add the green/violet duo)
